// Demo reference data: towns (lat, lon) and EV models [battery kWh, claimed range km, max AC kW]
const TOWNS={Rajahmundry:[17.0005,81.804],Kakinada:[16.9891,82.2475],Surampalem:[17.087,82.062],Peddapuram:[17.078,82.14],Samalkot:[17.052,82.174]};
const VEH={"Tata Nexon EV":[40.5,390,7.2],"Tata Punch EV":[35,365,7.2],"MG ZS EV":[50.3,461,7.4],"MG Comet EV":[17.3,230,3.3],"Mahindra BE 6":[59,535,11],"Hyundai Kona Electric":[39.2,452,7.2],"BYD Atto 3":[60.5,521,7],"Ather 450X":[3.7,110,0.8],"Ola S1 Pro":[4,195,0.9],"TVS iQube":[3.4,100,0.65]};
