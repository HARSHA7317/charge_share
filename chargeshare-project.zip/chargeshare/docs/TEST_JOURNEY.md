# Test journey (5 minutes)

1. **Landing**: pick a town, read host cards, try the voice box ("nearest charger").
2. **Owner**: login `owner1@demo.cs` / `Demo@123` → Rescue tab → set battery 12% → *Request instant charge* from a LIVE host.
3. **Host**: logout, login `host1@demo.cs` → Dashboard → *Accept* the 🆘 request.
4. **Owner**: login again → Bookings → *Pay* (simulated) → status Confirmed.
5. **Host**: Dashboard → *Mark completed* → earnings cards and 7-day chart update.
6. **Owner**: Bookings → *Review* → give stars. **Host**: Reviews → reply.
7. **Chat**: owner opens a charger → *Chat with host* → host replies in the Chat tab.
8. **Admin**: `admin@demo.cs` → statistics, suspend a user, approve a host, change platform fee.
9. **Register** a new account, edit profile, change password, add a vehicle or a charging point.
