// Optional: tiny static server. Run: npm install && npm start  ->  http://localhost:3000
const express = require('express');
const path = require('path');
const app = express();
app.use(express.static(__dirname, { extensions: ['html'] }));
app.get('/health', (_, res) => res.json({ ok: true, app: 'ChargeShare' }));
const port = process.env.PORT || 3000;
app.listen(port, () => console.log('ChargeShare running on http://localhost:' + port));
